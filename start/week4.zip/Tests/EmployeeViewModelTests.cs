﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests
{
    [TestClass]
   public class EmployeeViewModelTests
    {
        //private EmployeeViewModelTests o;

        [TestInitialize]
        public void TestInitialize()
        {
            //o = new EmployeeViewModel(null);
        }
        
        [TestMethod]
        public void SalaryColorIsRedByDefaultTest()
        {
            //Assert.AreEqual("red", o.SalaryColor);
        }

    }
}
